package com.dropwizard.mobileapp;

import java.util.Date;

public class Appointment {

    // Constants for maximum lengths
    private final byte appointmentIdLength;
    private final byte appointmentDescriptionLength;
    private final String initializer;

    // Instance variables
    private String appointmentId;
    private Date appointmentDate;
    private String description;

    // Initialization block to set constants
    {
        appointmentIdLength = 10;
        appointmentDescriptionLength = 50;
        initializer = "INITIAL";
    }

    // Default constructor
    public Appointment() {
        Date today = new Date();
        appointmentId = initializer;
        appointmentDate = today;
        description = initializer;
    }

    // Constructor with only ID
    public Appointment(String id) {
        Date today = new Date();
        updateAppointmentId(id);
        appointmentDate = today;
        description = initializer;
    }

    // Constructor with ID and date
    public Appointment(String id, Date date) {
        updateAppointmentId(id);
        updateDate(date);
        description = initializer;
    }

    // Constructor with ID, date, and description
    public Appointment(String id, Date date, String description) {
        updateAppointmentId(id);
        updateDate(date);
        updateDescription(description);
    }

    // Method to update appointment ID
    public void updateAppointmentId(String id) {
        if (id == null) {
            throw new IllegalArgumentException("Appointment ID cannot be null.");
        } else if (id.length() > appointmentIdLength) {
            throw new IllegalArgumentException("Appointment ID cannot exceed " +
                    appointmentIdLength +
                    " characters.");
        } else {
            this.appointmentId = id;
        }
    }

    // Getter for appointment ID
    public String getAppointmentId() {
        return appointmentId;
    }

    // Method to update appointment date
    public void updateDate(Date date) {
        if (date == null) {
            throw new IllegalArgumentException("Appointment date cannot be null.");
        } else if (date.before(new Date())) {
            throw new IllegalArgumentException("Cannot make appointment in the past.");
        } else {
            this.appointmentDate = date;
        }
    }

    // Getter for appointment date
    public Date getAppointmentDate() {
        return appointmentDate;
    }

    // Method to update appointment description
    public void updateDescription(String description) {
        if (description == null) {
            throw new IllegalArgumentException("Appointment description cannot be null.");
        } else if (description.length() > appointmentDescriptionLength) {
            throw new IllegalArgumentException("Appointment description cannot exceed " +
                    appointmentDescriptionLength + " characters.");
        } else {
            this.description = description;
        }
    }

    // Getter for appointment description
    public String getDescription() {
        return description;
    }
}
