package com.dropwizard.mobileapp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

public class AppointmentService {

    // List to store appointments
    final private List<Appointment> appointmentList = new ArrayList<>();

    // Generates a new unique ID
    private String newUniqueId() {
        return UUID.randomUUID().toString().substring(0, Math.min(toString().length(), 10));
    }

    // Creates a new appointment with a unique ID
    public void newAppointment() {
        Appointment appt = new Appointment(newUniqueId());
        appointmentList.add(appt);
    }

    // Creates a new appointment with a unique ID and given date
    public void newAppointment(Date date) {
        Appointment appt = new Appointment(newUniqueId(), date);
        appointmentList.add(appt);
    }

    // Creates a new appointment with a unique ID, date, and description
    public void newAppointment(Date date, String description) {
        Appointment appt = new Appointment(newUniqueId(), date, description);
        appointmentList.add(appt);
    }

    // Deletes an appointment with the given ID
    public void deleteAppointment(String id) throws Exception {
        appointmentList.remove(searchForAppointment(id));
    }

    // Returns the appointment list
    protected List<Appointment> getAppointmentList() {
        return appointmentList;
    }

    // Searches for an appointment with the given ID
    private Appointment searchForAppointment(String id) throws Exception {
        int index = 0;
        while (index < appointmentList.size()) {
            if (id.equals(appointmentList.get(index).getAppointmentId())) {
                return appointmentList.get(index);
            }
            index++;
        }
        throw new Exception("The appointment does not exist!");
    }
}
