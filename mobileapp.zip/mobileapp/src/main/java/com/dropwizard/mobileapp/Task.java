package com.dropwizard.mobileapp;

public class Task {

    // Instance variables for task properties
    private String taskId;
    private String name;
    private String description;

    // Default constructor with initial values
    Task() {
        taskId = "INITIAL";
        name = "INITIAL";
        description = "INITIAL DESCRIPTION";
    }

    // Constructor with only task ID
    Task(String taskId) {
        checkTaskId(taskId);
        name = "INITIAL";
        description = "INITIAL DESCRIPTION";
    }

    // Constructor with task ID and name
    Task(String taskId, String name) {
        checkTaskId(taskId);
        setName(name);
        description = "INITIAL DESCRIPTION";
    }

    // Constructor with task ID, name, and description
    Task(String taskId, String name, String desc) {
        checkTaskId(taskId);
        setName(name);
        setDescription(desc);
    }

    // Getter for task ID
    public final String getTaskId() {
        return taskId;
    }

    // Getter for task name
    public final String getName() {
        return name;
    }

    // Setter for task name
    protected void setName(String name) {
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException(
                "Task name is invalid. Ensure it is shorter than 20 characters and not empty.");
        } else {
            this.name = name;
        }
    }

    // Getter for task description
    public final String getDescription() {
        return description;
    }

    // Setter for task description
    protected void setDescription(String taskDescription) {
        if (taskDescription == null || taskDescription.length() > 50) {
            throw new IllegalArgumentException(
                "Task description is invalid. Ensure it is shorter than 50 characters and not empty.");
        } else {
            this.description = taskDescription;
        }
    }

    // Method to check and set task ID
    private void checkTaskId(String taskId) {
        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException(
                "Error: The task ID was null or longer than 10 characters");
        } else {
            this.taskId = taskId;
        }
    }
}
