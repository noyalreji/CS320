package com.dropwizard.mobileapp;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class TaskService {

    // List to store tasks
    private final List<Task> taskList = new ArrayList<>();

    // Method to generate a new unique ID
    private String newUniqueId() {
        return UUID.randomUUID().toString().substring(0, Math.min(toString().length(), 10));
    }

    // Method to search for a task by ID
    private Task searchForTask(String id) throws Exception {
        int index = 0;
        while (index < taskList.size()) {
            if (id.equals(taskList.get(index).getTaskId())) {
                return taskList.get(index);
            }
            index++;
        }
        throw new Exception("The Task does not exist!");
    }

    // Method to create a new task with a unique ID
    public void newTask() {
        Task task = new Task(newUniqueId());
        taskList.add(task);
    }

    // Method to create a new task with a unique ID and name
    public void newTask(String name) {
        Task task = new Task(newUniqueId(), name);
        taskList.add(task);
    }

    // Method to create a new task with a unique ID, name, and description
    public void newTask(String name, String description) {
        Task task = new Task(newUniqueId(), name, description);
        taskList.add(task);
    }

    // Method to delete a task by ID
    public void deleteTask(String id) throws Exception {
        taskList.remove(searchForTask(id));
    }

    // Method to update name of a task by ID
    public void updateName(String id, String name) throws Exception {
        searchForTask(id).setName(name);
    }

    // Method to update description of a task by ID
    public void updateDescription(String id, String description) throws Exception {
        searchForTask(id).setDescription(description);
    }

    // Method to get the list of tasks
    public List<Task> getTaskList() {
        return taskList;
    }
}
